# fps (fake product scanner)

FPS is a mobile app that allows the manufacturer to track their products. The project uses the blockchain technology to identify fake products. The users can scan product Qr to identify. #FINTECH

#Installation

-install flutter framework
-in the project  terminal: flutter pub get

#run

- flutter run

#verified user

- username: kiran@gmail.com
- password: kiran123


