package com.example.fps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
