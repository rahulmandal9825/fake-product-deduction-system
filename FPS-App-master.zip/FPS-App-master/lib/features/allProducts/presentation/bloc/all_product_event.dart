part of 'all_product_bloc.dart';

@immutable
abstract class AllProductEvent {}

class GetAllProduct implements AllProductEvent {}
