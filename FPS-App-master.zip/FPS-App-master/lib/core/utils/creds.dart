// const String relayWallet =
//     "d594a1ddef034e2b87337675ab7511b5fbfc21b1536e78b6d4db78bc76db0448";

// const String apiUrl = "https://rpc-mumbai.matic.today";

// const String contractAddress = "0x0222e6CeF084b04FAF19e0E6988E67c2Fd41B5b6";

const String relayWallet =
    "084a4a3357ce36153145d31c5e65ee6153162c449a0b6466829995e0d8f5aedb";

const String apiUrl = "HTTP://192.168.1.20:7545";

const String contractAddress = "0x80f4Fc0A08e8E15c3759641ffE8e50Cf39a9e4f8";
